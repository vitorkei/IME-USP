void multiplot_start __PROTO((void));
void multiplot_end __PROTO((void));
void multiplot_next __PROTO((void));
int multiplot_current_panel __PROTO((void));
