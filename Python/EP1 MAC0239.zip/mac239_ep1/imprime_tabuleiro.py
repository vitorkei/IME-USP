__author__ = 'kiko'

def imprime(N, posx_rainha, posy_rainha):

    # monta o tabuleiro com pontos
    for casa_x in range(N):
        for casa_y in range(N):
            print("")






