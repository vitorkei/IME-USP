READ ME - Problema de conexidade 2D

Nome: Vítor Kei Taira Tamada
NUSP: 8516250

Arquivos escritos/alterados para este exercício:
  PC2D.java

Bibliotecas e programas auxiliares:
  UF.java
  Point2D.java
  ST.java
  StdIn.java
  StdOut.java

Arquivo de teste utilizado:
  

Comandos de compilação:
  javac PC2D.java

Comando de execução:
  java PC2D < input.txt

Notas:
-Os comandos de compilação e execução escritos aqui são os utilizados nos testes;
-Foram gerados arquivos de 10^5 e 10^6 pontos distribuídos aleatoriamente pelo quadrado para testar o programa, além de arquivos com a mesma quantidade de pontos, mas distribuídos apenas na metade inferior do quadrado e um ponto solitario no topo.

