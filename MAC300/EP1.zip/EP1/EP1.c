/*
    MAC 300 - Métodos Numéricos de Álgebra Linear

    Nome: Vítor Kei Taira Tamada
    NUSP: 8516250
    Exercício-programa 1 - Resolução de sistemas de equações lineares

*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/* Funções auxiliares */
double** cria_matriz (FILE*);
int sing_test (double**);
double** mult_matriz (double**, double**);

/* Primeira parte - sistemas definidos positivos */

/* Implementação por coluna */
int cholcol (int, double**);
int forwcol (int, double**, double);
int backcol (int, double**, double*, int);

/* Implementação por linha */
int cholrow (int, double**);
int forwcol (int, double**, double);
int backcol (int, double**, double*, int);

int main ()
{
    /* Declaração de variáveis */
    FILE *file;
    char filePath[100];
    double **A;

    /* Recebe um arquivo */
    printf ("\nInsira o nome do arquivo que contém a matriz:\n");
    scanf ("%s", filePath);

    /* Verifica se o arquivo inserido existe e/ou foi inserido com sucesso */
    file = fopen (filePath, "r");
    if (file == NULL)
    {
        printf ("\n***** Erro ao abrir o arquivo *****\n\n");
        exit (-1);
    }

    A = cria_matriz (file);

    /*
    ***** IMPRESSÕES DE TESTE *****

    printf ("\nn = %d\n\n", n);

    for (i = 0; i < n; i++)
    {
        printf ("i = %d\n", i);
        for (j = 0; j < n; j++)
        {
            printf ("%f\n", A[i][j]);
        }
        printf ("**************************\n");
    }

    fclose (file);

    printf ("\n\nplaceholder\n\n");

    */

    return 0;
}

double** cria_matriz (FILE* file)
{
    int n, i, j, aux_i, aux_j;
    double num, **A;

    /* Recebe a dimensão da matriz e verifica se é um valor válido */
    fscanf (file, "%d", &n);
    if (n <= 0)
    {
        printf ("\n***** Dimensão de matriz inválida *****\n\n");
        exit (-1);
    }

    /* Cria a matriz */
    A = malloc (n * sizeof (double *));
    for (i = 0; i < n; i++)
        A[i] = malloc (n * sizeof (double));

    for (aux_i = 0; aux_i < n; aux_i++)
    {
        for (aux_j = 0; aux_j < n; aux_j++)
        {
            fscanf (file, "%d", &i);
            fscanf (file, "%d", &j);
            fscanf (file, "%lf", &num);
            A[i][j] = num;
        }
    }

    return A;
}

/* Multiplica duas matrizes */
double** mult_matriz (int n, int m, double **A, double **B)
{
    int i, j, k;
    double **x, sum;

    sum = 0;

    x = malloc (n * sizeof (double *));
    for (i = 0; i < n; i++)
        x[i] = malloc (m * sizeof (double));
        
}

/* Verifica se a matriz é singular verificando se ela é definida positiva */
int sing_teste (int n, double **A)
{
    
}
